# clean-folder
This is a file janitor package that will clean up the specified folder for you.